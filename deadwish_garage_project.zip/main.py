
import pygame
import time

pygame.init()
pygame.mixer.init()

# Scherminstellingen
screen = pygame.display.set_mode((1000, 600))
pygame.display.set_caption("Deadwish: Garage Protocol")

# Kleuren
WHITE = (255, 255, 255)
GRAY = (180, 180, 180)
BLACK = (0, 0, 0)
RED = (200, 50, 50)
GREEN = (50, 200, 50)
BLUE = (50, 150, 255)

# Lettertypes
font = pygame.font.SysFont(None, 36)
small_font = pygame.font.SysFont(None, 24)

# Geluid
arrival_sound = pygame.mixer.Sound("arrival.wav")
arrival_sound_played = False

# Game states
game_state = "garage"

# Reminder systeem
reminder_active = True
reminder_start_time = time.time()
arrival_triggered = False
arrival_time_seconds = 15
destination_timer_start = time.time()
show_countdown = True

reminders = [
    "MO-Top-Up voor Deadwish",
    "Controle: Licentie Actief?",
    "Upgrade Mustang met Console",
    "Aankomst: Marc X Garage"
]

def draw_garage():
    screen.fill((30, 30, 30))
    title = font.render("🚗 Deadwish Garage - Outerpoort", True, WHITE)
    screen.blit(title, (20, 20))

def draw_reminder(text):
    pygame.draw.rect(screen, (80, 80, 80), (250, 80, 500, 60))
    pygame.draw.rect(screen, (200, 200, 0), (250, 80, 500, 60), 3)
    label = font.render(text, True, WHITE)
    screen.blit(label, (270, 95))

def draw_navigation_status():
    if show_countdown:
        elapsed = time.time() - destination_timer_start
        remaining = max(0, int(arrival_time_seconds - elapsed))

        pygame.draw.rect(screen, BLACK, (20, 60, 280, 50))
        pygame.draw.rect(screen, BLUE, (20, 60, 280, 50), 2)

        loc_label = small_font.render("📍 Naar: Marc X Garage Village", True, WHITE)
        time_label = small_font.render(f"⏱️ Aankomst in: {remaining} sec", True, WHITE)

        screen.blit(loc_label, (30, 65))
        screen.blit(time_label, (30, 85))

def draw_map():
    pygame.draw.rect(screen, (40, 40, 40), (700, 400, 280, 180))
    pygame.draw.rect(screen, WHITE, (700, 400, 280, 180), 2)

    label = small_font.render("🗺️ Kaart", True, WHITE)
    screen.blit(label, (710, 405))

    pygame.draw.circle(screen, RED, (740, 450), 8)
    screen.blit(small_font.render("Outerpoort", True, WHITE), (755, 445))

    pygame.draw.circle(screen, GREEN, (940, 540), 8)
    screen.blit(small_font.render("Marc X Garage", True, WHITE), (855, 535))

    progress = min(1, (time.time() - destination_timer_start) / arrival_time_seconds)
    x = 740 + int((940 - 740) * progress)
    y = 450 + int((540 - 450) * progress)
    pygame.draw.circle(screen, BLUE, (x, y), 6)

def draw_agenda():
    pygame.draw.rect(screen, (25, 25, 25), (20, 400, 280, 180))
    pygame.draw.rect(screen, WHITE, (20, 400, 280, 180), 2)

    screen.blit(small_font.render("📅 Agenda / Reminders", True, WHITE), (30, 405))

    for i, item in enumerate(reminders):
        screen.blit(small_font.render(f"- {item}", True, GRAY), (35, 430 + i * 25))

# Main loop
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    if game_state == "garage":
        draw_garage()
        draw_navigation_status()
        draw_map()
        draw_agenda()

    current_time = time.time()

    if game_state == "garage" and reminder_active:
        if current_time - reminder_start_time < 5:
            draw_reminder("🛠️ Vergeet je MO-top-up niet!")
        else:
            reminder_active = False

    elapsed_drive = current_time - destination_timer_start
    if game_state == "garage" and not arrival_triggered:
        if elapsed_drive > arrival_time_seconds:
            arrival_triggered = True
            reminder_active = True
            reminder_start_time = time.time()
            if not arrival_sound_played:
                arrival_sound.play()
                arrival_sound_played = True
    elif game_state == "garage" and arrival_triggered:
        if current_time - reminder_start_time < 5:
            draw_reminder("🚗 Aankomst bij Marc X Garage Village")

    pygame.display.update()
